const { pool, query } = require('../../config/db');
const transportService = require('./transport.service');
const ledgerService = require('../customers/ledger.service');
const ceilingsService = require('../ceilings/ceilings.service');

const generateOrderNumber = async () => {
  const year = new Date().getFullYear();
  const r = await query(
    `SELECT COUNT(*) FROM orders WHERE order_number LIKE $1`,
    [`GHO-${year}-%`]
  );
  return `GHO-${year}-${String(parseInt(r.rows[0].count, 10) + 1).padStart(6, '0')}`;
};

const checkCreditAvailability = async (client, customerId, additionalAmount) => {
  const cust = await client.query(
    `SELECT current_balance, credit_limit FROM customers WHERE id = $1`,
    [customerId]
  );
  if (cust.rows.length === 0) {
    const err = new Error('العميل غير موجود');
    err.status = 404;
    throw err;
  }
  const balance = parseFloat(cust.rows[0].current_balance || 0);
  const limit = parseFloat(cust.rows[0].credit_limit || 0);

  const pending = await client.query(
    `SELECT COALESCE(SUM(credit_amount), 0) AS total FROM orders
     WHERE customer_id = $1 AND status = 'PENDING_ADMIN_APPROVAL'`,
    [customerId]
  );
  const pendingBalance = parseFloat(pending.rows[0].total || 0);
  const total = balance + pendingBalance + additionalAmount;
  const unlimited = limit === 0;

  return {
    current_balance: balance,
    pending_balance: pendingBalance,
    additional_amount: additionalAmount,
    total_after: total,
    credit_limit: limit,
    has_limit: !unlimited,
    can_approve: unlimited || total <= limit,
    available_credit: unlimited ? null : Math.max(0, limit - balance - pendingBalance),
  };
};

const createOrder = async (userId, data) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const cust = await client.query(
      `SELECT id, customer_type, current_balance, credit_limit, governorate, area
       FROM customers WHERE user_id = $1`,
      [userId]
    );
    if (cust.rows.length === 0) {
      const err = new Error('العميل غير موجود');
      err.status = 404;
      throw err;
    }
    const customerId = cust.rows[0].id;
    const customer = cust.rows[0];

    let addressId = data.addressId;

    if (data.deliveryType === 'alghouli_delivery') {
      if (!addressId) {
        const err = new Error('عنوان التسليم مطلوب');
        err.status = 400;
        throw err;
      }
      const a = await client.query(
        `SELECT id FROM customer_addresses WHERE id = $1 AND customer_id = $2`,
        [addressId, customerId]
      );
      if (a.rows.length === 0) {
        const err = new Error('العنوان غير موجود');
        err.status = 404;
        throw err;
      }
    } else if (data.deliveryType === 'trader_pickup') {
      if (!data.traderTruckPlate || !data.traderDriverName) {
        const err = new Error('رقم الشاحنة واسم السائق مطلوبان');
        err.status = 400;
        throw err;
      }
      const ex = await client.query(
        `SELECT id FROM customer_addresses WHERE customer_id = $1 AND is_default = true LIMIT 1`,
        [customerId]
      );
      if (ex.rows.length > 0) {
        addressId = ex.rows[0].id;
      } else {
        const n = await client.query(
          `INSERT INTO customer_addresses
           (customer_id, label, governorate, area, address_text, is_default)
           VALUES ($1, 'افتراضي', $2, $3, 'يُحدد', true) RETURNING id`,
          [customerId, customer.governorate || 'صنعاء', customer.area || '']
        );
        addressId = n.rows[0].id;
      }
    }

    // لا يُحدَّد سعر هنا إطلاقًا (مواصفة الواجهة الجديدة، بند 13/17/21): العميل يختار
    // المصنع والنوع والكمية فقط، والموظف المخوَّل يحدد السعر لاحقًا عبر setOrderPricing.
    const items = [];
    for (const item of data.items) {
      const p = await client.query(
        `SELECT p.id, p.source_id, p.packaging_type, p.name_ar,
                COALESCE(i.unit, CASE WHEN p.packaging_type = 'bagged' THEN 'bag' ELSE 'ton' END) AS unit,
                COALESCE(i.available_qty, 0) AS available_qty
         FROM products p
         LEFT JOIN inventory i ON i.product_id = p.id
         WHERE p.id = $1`,
        [item.productId]
      );
      if (p.rows.length === 0) {
        const err = new Error('المنتج غير موجود');
        err.status = 404;
        throw err;
      }
      const product = p.rows[0];

      if (parseFloat(product.available_qty) < item.quantity) {
        const err = new Error(`الكمية غير كافية من: ${product.name_ar}`);
        err.status = 400;
        err.code = 'INSUFFICIENT_STOCK';
        throw err;
      }

      items.push({
        productId: product.id,
        sourceId: product.source_id,
        packagingType: product.packaging_type,
        quantity: item.quantity,
        unit: product.unit,
      });
    }

    // فحص سقوف الكمية (بند 28) — يعتمد على الكمية فقط لأن السعر غير معروف بعد.
    // سقوف القيمة (بالريال) تُفحص لاحقًا عند التسعير في setOrderPricing.
    try {
      const bySource = {};
      for (const it of items) {
        const s = (bySource[it.sourceId] ||= { bags: 0 });
        if (it.unit === 'bag') s.bags += it.quantity;
      }
      for (const [sourceId, agg] of Object.entries(bySource)) {
        const check = await ceilingsService.checkOrderCeilings(client, {
          customerId, sourceId, categoryId: null,
          requestedBags: agg.bags, requestedAmount: 0,
        });
        if (check.exceeded) {
          const err = new Error('تم تجاوز السقف المسموح به لهذا الطلب. يمكنك إرسال طلب موافقة استثنائية.');
          err.status = 400;
          err.code = 'CEILING_EXCEEDED';
          err.data = check.results.filter((r) => r.exceeded);
          throw err;
        }
      }
    } catch (ceilErr) {
      if (ceilErr.code === 'CEILING_EXCEEDED') throw ceilErr;
      console.error('تحذير: تعذّر فحص سقوف الطلبات (تم تجاوز الفحص):', ceilErr.message);
    }

    const initialStatus = 'PENDING_PRICING';
    const orderNumber = await generateOrderNumber();

    const o = await client.query(
      `INSERT INTO orders
       (order_number, customer_id, address_id, status, source,
        subtotal, discount_amount, shipping_amount, total_amount,
        paid_amount, remaining_amount, notes, created_by,
        delivery_type, trader_truck_plate, trader_driver_name, trader_driver_phone,
        transport_unit)
       VALUES ($1, $2, $3, $4, 'ONLINE',
               NULL, 0, NULL, NULL, 0, NULL, $5, $6,
               $7, $8, $9, $10, $11)
       RETURNING id, order_number, status, created_at`,
      [
        orderNumber, customerId, addressId, initialStatus,
        data.notes || null, userId,
        data.deliveryType, data.traderTruckPlate || null,
        data.traderDriverName || null, data.traderDriverPhone || null,
        items[0]?.unit || 'bag',
      ]
    );
    const order = o.rows[0];

    for (const it of items) {
      await client.query(
        `INSERT INTO order_items
         (order_id, product_id, source_id, packaging_type, quantity, unit,
          unit_price, discount, line_total)
         VALUES ($1, $2, $3, $4, $5, $6, NULL, 0, NULL)`,
        [order.id, it.productId, it.sourceId, it.packagingType, it.quantity, it.unit]
      );
      await client.query(
        `UPDATE inventory SET reserved_qty = reserved_qty + $1, updated_at = NOW()
         WHERE product_id = $2`,
        [it.quantity, it.productId]
      );
    }

    await client.query(
      `INSERT INTO order_status_history (order_id, from_status, to_status, changed_by, reason)
       VALUES ($1, NULL, $2, $3, 'طلب جديد بانتظار التسعير')`,
      [order.id, initialStatus, userId]
    );

    await client.query('COMMIT');
    return { ...order, delivery_type: data.deliveryType };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

/**
 * تسعير الطلب من موظف مخوَّل (بند 21-23): يحدد سعر كل عنصر + أجرة النقل، وتُحسب
 * القيمة الإجمالية تلقائيًا. لا يمكن للعميل رؤية أي سعر قبل هذه الخطوة، ولا يمكن
 * تسعير طلب أكثر من مرة عبر هذا المسار (تعديل لاحق يكون عبر إجراء منفصل + سجل تعديل).
 */
const setOrderPricing = async (orderId, staffUserId, data) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const o = await client.query(`SELECT * FROM orders WHERE id = $1 FOR UPDATE`, [orderId]);
    if (o.rows.length === 0) { const e = new Error('الطلب غير موجود'); e.status = 404; throw e; }
    const order = o.rows[0];
    if (order.status !== 'PENDING_PRICING') {
      const e = new Error('لا يمكن تسعير الطلب في حالته الحالية'); e.status = 400; throw e;
    }

    const existingItems = await client.query(`SELECT * FROM order_items WHERE order_id = $1`, [orderId]);
    const priceById = new Map((data.items || []).map((i) => [i.orderItemId, i]));

    let subtotal = 0;
    let bySourceAmount = {};
    for (const item of existingItems.rows) {
      const input = priceById.get(item.id);
      if (!input) { const e = new Error(`سعر مفقود لعنصر الطلب ${item.id}`); e.status = 400; throw e; }
      const unitPrice = parseFloat(input.unitPrice);
      const discount = parseFloat(input.discount || 0);
      if (!(unitPrice >= 0)) { const e = new Error('سعر غير صحيح'); e.status = 400; throw e; }
      const lineTotal = unitPrice * parseFloat(item.quantity) - discount;
      subtotal += lineTotal;
      bySourceAmount[item.source_id] = (bySourceAmount[item.source_id] || 0) + lineTotal;

      await client.query(
        `UPDATE order_items SET unit_price = $1, discount = $2, line_total = $3 WHERE id = $4`,
        [unitPrice, discount, lineTotal, item.id]
      );
    }

    const transportAmount = parseFloat(data.transportAmount || 0);
    const totalAmount = subtotal + transportAmount;

    // فحص سقوف القيمة الآن بعد معرفتها (تحذير فقط: لا يوقف الموظف، فهو مخوَّل بالفعل)
    try {
      for (const [sourceId, amount] of Object.entries(bySourceAmount)) {
        const check = await ceilingsService.checkOrderCeilings(client, {
          customerId: order.customer_id, sourceId, categoryId: null,
          requestedBags: 0, requestedAmount: amount,
        });
        if (check.exceeded) {
          console.warn(`تنبيه: تسعير الطلب ${order.order_number} يتجاوز سقف القيمة المحدد لهذا العميل/المصنع.`);
        }
      }
    } catch (ceilErr) {
      console.error('تعذّر فحص سقوف القيمة عند التسعير (تم تجاوزه):', ceilErr.message);
    }

    await client.query(
      `UPDATE orders SET
         subtotal = $1, shipping_amount = $2, total_amount = $3, remaining_amount = $3,
         status = 'PENDING_PAYMENT_METHOD', priced_by = $4, priced_at = NOW(), updated_at = NOW()
       WHERE id = $5`,
      [subtotal, transportAmount, totalAmount, staffUserId, orderId]
    );

    await client.query(
      `INSERT INTO order_status_history (order_id, from_status, to_status, changed_by, reason)
       VALUES ($1, 'PENDING_PRICING', 'PENDING_PAYMENT_METHOD', $2, 'تم تحديد السعر')`,
      [orderId, staffUserId]
    );

    // إشعار العميل بقيمة الطلب (بند 23) — غير حرج: لا يوقف التسعير لو فشل
    try {
      await client.query('SAVEPOINT price_notify_sp');
      const cust = await client.query(
        `SELECT u.id AS user_id FROM customers c JOIN users u ON u.id = c.user_id WHERE c.id = $1`,
        [order.customer_id]
      );
      if (cust.rows[0]) {
        await client.query(
          `INSERT INTO notifications (user_id, title_ar, body_ar, type, reference_type, reference_id)
           VALUES ($1, 'تم تحديد قيمة طلبك', $2, 'ORDER_PRICED', 'orders', $3)`,
          [cust.rows[0].user_id, `إشعار قيمة الطلب رقم ${order.order_number}: ${totalAmount.toLocaleString('en-US')} ريال. يرجى اختيار طريقة السداد.`, orderId]
        );
      }
    } catch (notifyErr) {
      await client.query('ROLLBACK TO SAVEPOINT price_notify_sp');
      console.error('تعذّر إرسال إشعار التسعير (تم تجاهله):', notifyErr.message);
    }

    await client.query('COMMIT');
    return { id: orderId, status: 'PENDING_PAYMENT_METHOD', subtotal, shipping_amount: transportAmount, total_amount: totalAmount };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

/**
 * اختيار طريقة السداد بعد معرفة السعر (بند 24): فوري / آجل / جزئي.
 * هذه الخطوة تحل محل منطق الدفع الذي كان يحدث عند الإنشاء سابقًا، وتُبقي
 * على نفس تدفق العمل بعدها دون تغيير (اعتماد الائتمان / رفع إيصال الدفع).
 */
const choosePaymentMethod = async (orderId, userId, data) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const cust = await client.query(`SELECT id FROM customers WHERE user_id = $1`, [userId]);
    if (cust.rows.length === 0) { const e = new Error('العميل غير موجود'); e.status = 404; throw e; }
    const customerId = cust.rows[0].id;

    const o = await client.query(
      `SELECT * FROM orders WHERE id = $1 AND customer_id = $2 FOR UPDATE`,
      [orderId, customerId]
    );
    if (o.rows.length === 0) { const e = new Error('الطلب غير موجود'); e.status = 404; throw e; }
    const order = o.rows[0];
    if (order.status !== 'PENDING_PAYMENT_METHOD') {
      const e = new Error('لا يمكن اختيار طريقة السداد في هذه الحالة'); e.status = 400; throw e;
    }
    const totalAmount = parseFloat(order.total_amount);
    const paymentTerms = data.paymentTerms;

    let paidNow = 0;
    let creditAmount = 0;
    if (paymentTerms === 'cash') {
      paidNow = totalAmount;
    } else if (paymentTerms === 'credit') {
      creditAmount = totalAmount;
    } else if (paymentTerms === 'partial') {
      paidNow = parseFloat(data.paidAmountNow || 0);
      if (paidNow < 0 || paidNow > totalAmount) { const e = new Error('المبلغ المدفوع غير صحيح'); e.status = 400; throw e; }
      creditAmount = totalAmount - paidNow;
    }

    let creditCheck = null;
    if (creditAmount > 0) {
      creditCheck = await checkCreditAvailability(client, customerId, creditAmount);
      if (!creditCheck.can_approve) {
        const e = new Error(`تجاوز الحد الائتماني. الرصيد: ${creditCheck.current_balance}، الحد: ${creditCheck.credit_limit}`);
        e.status = 400; e.code = 'CREDIT_LIMIT_EXCEEDED'; e.data = creditCheck;
        throw e;
      }
    }

    const nextStatus = creditAmount > 0 ? 'PENDING_ADMIN_APPROVAL' : 'PENDING_PAYMENT';

    await client.query(
      `UPDATE orders SET payment_terms = $1, paid_amount_now = $2, credit_amount = $3,
         status = $4, updated_at = NOW() WHERE id = $5`,
      [paymentTerms, paidNow, creditAmount, nextStatus, orderId]
    );

    if (creditAmount > 0) {
      await ledgerService.addTransaction(client, {
        customerId, orderId,
        transactionType: 'purchase',
        debit: creditAmount,
        description: `طلب ${order.order_number} - ${paymentTerms === 'partial' ? 'دفع جزئي' : 'آجل'}`,
        createdBy: userId,
      });
    }

    await client.query(
      `INSERT INTO order_status_history (order_id, from_status, to_status, changed_by, reason)
       VALUES ($1, 'PENDING_PAYMENT_METHOD', $2, $3, $4)`,
      [orderId, nextStatus, userId,
        paymentTerms === 'credit' ? 'طلب آجل' : paymentTerms === 'partial' ? 'دفع جزئي' : 'طلب فوري']
    );

    await client.query('COMMIT');
    return {
      id: orderId, status: nextStatus, payment_terms: paymentTerms,
      paid_amount_now: paidNow, credit_amount: creditAmount, credit_check: creditCheck,
    };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

/**
 * الطلب الجماعي للتاجر (بند 27): طلب واحد لمصنع/نوع أسمنت، بقاطرات متعددة —
 * كل قاطرة تصبح طلبًا مستقلاً كاملاً (يُسعَّر ويُسدَّد بشكل منفصل)، مرتبطة
 * جميعها برقم مجموعة واحد GR-YYYY-XXXXXX. لا يُنشئ نظام طلبات ثانٍ — يعيد
 * استخدام نفس جدول orders ونفس دورة العمل (PENDING_PRICING ثم...).
 */
const createGroupOrder = async (userId, data) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const cust = await client.query(
      `SELECT id, customer_type, governorate, area FROM customers WHERE user_id = $1`,
      [userId]
    );
    if (cust.rows.length === 0) { const e = new Error('العميل غير موجود'); e.status = 404; throw e; }
    const customer = cust.rows[0];
    const customerId = customer.id;
    if (!['trader', 'distributor'].includes(customer.customer_type)) {
      const e = new Error('الطلب الجماعي متاح للتجار والموزعين فقط'); e.status = 403; throw e;
    }
    if (!Array.isArray(data.trucks) || data.trucks.length < 2) {
      const e = new Error('الطلب الجماعي يحتاج قاطرتين على الأقل (لطلب قاطرة واحدة استخدم الطلب العادي)');
      e.status = 400; throw e;
    }

    const p = await client.query(
      `SELECT p.id, p.source_id, p.packaging_type, p.name_ar,
              COALESCE(i.unit, CASE WHEN p.packaging_type = 'bagged' THEN 'bag' ELSE 'ton' END) AS unit,
              COALESCE(i.available_qty, 0) AS available_qty
       FROM products p LEFT JOIN inventory i ON i.product_id = p.id
       WHERE p.id = $1`,
      [data.productId]
    );
    if (p.rows.length === 0) { const e = new Error('المنتج غير موجود'); e.status = 404; throw e; }
    const product = p.rows[0];

    const totalQuantity = data.trucks.reduce((s, t) => s + parseFloat(t.quantity || 0), 0);
    if (parseFloat(product.available_qty) < totalQuantity) {
      const e = new Error(`الكمية الإجمالية غير كافية من: ${product.name_ar}`);
      e.status = 400; e.code = 'INSUFFICIENT_STOCK'; throw e;
    }

    // فحص سقف الكمية على إجمالي المجموعة دفعة واحدة (بدل فحص كل طلب منفرد لاحقًا
    // بلا رؤية بعضها البعض ضمن نفس المعاملة)
    try {
      if (product.unit === 'bag') {
        const check = await ceilingsService.checkOrderCeilings(client, {
          customerId, sourceId: product.source_id, categoryId: null,
          requestedBags: totalQuantity, requestedAmount: 0,
        });
        if (check.exceeded) {
          const e = new Error('تجاوزت الكمية الإجمالية للمجموعة السقف المسموح به.');
          e.status = 400; e.code = 'CEILING_EXCEEDED'; e.data = check.results.filter((r) => r.exceeded);
          throw e;
        }
      }
    } catch (ceilErr) {
      if (ceilErr.code === 'CEILING_EXCEEDED') throw ceilErr;
      console.error('تحذير: تعذّر فحص سقوف الطلب الجماعي (تم تجاوز الفحص):', ceilErr.message);
    }

    let addressId = data.addressId || null;
    if (!addressId) {
      const ex = await client.query(
        `SELECT id FROM customer_addresses WHERE customer_id = $1 AND is_default = true LIMIT 1`,
        [customerId]
      );
      if (ex.rows.length > 0) {
        addressId = ex.rows[0].id;
      } else {
        const n = await client.query(
          `INSERT INTO customer_addresses (customer_id, label, governorate, area, address_text, is_default)
           VALUES ($1, 'افتراضي', $2, $3, 'يُحدد', true) RETURNING id`,
          [customerId, customer.governorate || 'صنعاء', customer.area || '']
        );
        addressId = n.rows[0].id;
      }
    }

    const year = new Date().getFullYear();
    const gCount = await client.query(`SELECT COUNT(*) FROM order_groups WHERE group_number LIKE $1`, [`GR-${year}-%`]);
    const groupNumber = `GR-${year}-${String(parseInt(gCount.rows[0].count, 10) + 1).padStart(6, '0')}`;
    const g = await client.query(
      `INSERT INTO order_groups (group_number, customer_id) VALUES ($1, $2) RETURNING id`,
      [groupNumber, customerId]
    );
    const groupId = g.rows[0].id;

    const createdOrders = [];
    for (const truck of data.trucks) {
      const qty = parseFloat(truck.quantity);
      if (!(qty > 0)) { const e = new Error('كمية غير صحيحة لإحدى القاطرات'); e.status = 400; throw e; }
      if (!truck.truckPlate || !truck.driverName) {
        const e = new Error('رقم القاطرة واسم السائق مطلوبان لكل قاطرة في المجموعة'); e.status = 400; throw e;
      }

      const orderNumber = await generateOrderNumber();
      const o = await client.query(
        `INSERT INTO orders
         (order_number, customer_id, address_id, status, source,
          subtotal, discount_amount, shipping_amount, total_amount,
          paid_amount, remaining_amount, notes, created_by,
          delivery_type, trader_truck_plate, trader_driver_name, trader_driver_phone,
          transport_unit, group_id)
         VALUES ($1, $2, $3, 'PENDING_PRICING', 'ONLINE',
                 NULL, 0, NULL, NULL, 0, NULL, $4, $5,
                 'trader_pickup', $6, $7, $8, $9, $10)
         RETURNING id, order_number, status, created_at`,
        [
          orderNumber, customerId, addressId, data.notes || null, userId,
          truck.truckPlate, truck.driverName, truck.driverPhone || null,
          product.unit, groupId,
        ]
      );
      const order = o.rows[0];

      await client.query(
        `INSERT INTO order_items (order_id, product_id, source_id, packaging_type, quantity, unit, unit_price, discount, line_total)
         VALUES ($1, $2, $3, $4, $5, $6, NULL, 0, NULL)`,
        [order.id, product.id, product.source_id, product.packaging_type, qty, product.unit]
      );
      await client.query(
        `UPDATE inventory SET reserved_qty = reserved_qty + $1, updated_at = NOW() WHERE product_id = $2`,
        [qty, product.id]
      );
      await client.query(
        `INSERT INTO order_status_history (order_id, from_status, to_status, changed_by, reason)
         VALUES ($1, NULL, 'PENDING_PRICING', $2, $3)`,
        [order.id, userId, `جزء من الطلب الجماعي ${groupNumber}`]
      );

      createdOrders.push({ ...order, truck_plate: truck.truckPlate, quantity: qty });
    }

    await client.query('COMMIT');
    return { groupId, groupNumber, orders: createdOrders };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

const getGroupOrder = async (groupId, customerId) => {
  const g = await query(
    `SELECT * FROM order_groups WHERE id = $1 AND customer_id = $2`,
    [groupId, customerId]
  );
  if (g.rows.length === 0) { const e = new Error('المجموعة غير موجودة'); e.status = 404; throw e; }
  const orders = await query(
    `SELECT o.id, o.order_number, o.status, o.total_amount, o.trader_truck_plate, o.trader_driver_name,
            oi.quantity, oi.unit
     FROM orders o JOIN order_items oi ON oi.order_id = o.id
     WHERE o.group_id = $1 ORDER BY o.created_at ASC`,
    [groupId]
  );
  return { ...g.rows[0], orders: orders.rows };
};

const listPendingPricing = async () => {
  const r = await query(
    `SELECT o.id, o.order_number, o.delivery_type, o.created_at,
            u.full_name AS customer_name, u.phone AS customer_phone
     FROM orders o
     JOIN customers c ON c.id = o.customer_id
     JOIN users u ON u.id = c.user_id
     WHERE o.status = 'PENDING_PRICING'
     ORDER BY o.created_at ASC`
  );
  return r.rows;
};

const approveCreditOrder = async (orderId, adminId) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const o = await client.query(
      `SELECT id, status FROM orders WHERE id = $1 FOR UPDATE`,
      [orderId]
    );
    if (o.rows.length === 0) {
      const err = new Error('الطلب غير موجود');
      err.status = 404;
      throw err;
    }
    if (o.rows[0].status !== 'PENDING_ADMIN_APPROVAL') {
      const err = new Error('الطلب ليس بانتظار الموافقة');
      err.status = 400;
      throw err;
    }
    await client.query(
      `UPDATE orders SET status = 'PREPARING', credit_approved_by = $1,
       credit_approved_at = NOW(), updated_at = NOW() WHERE id = $2`,
      [adminId, orderId]
    );
    await client.query(
      `INSERT INTO order_status_history (order_id, from_status, to_status, changed_by, reason)
       VALUES ($1, 'PENDING_ADMIN_APPROVAL', 'PREPARING', $2, 'موافقة المدير')`,
      [orderId, adminId]
    );
    await client.query('COMMIT');
    return { id: orderId, status: 'PREPARING' };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

const rejectCreditOrder = async (orderId, adminId, reason) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const o = await client.query(
      `SELECT id, status, customer_id, credit_amount FROM orders WHERE id = $1 FOR UPDATE`,
      [orderId]
    );
    if (o.rows.length === 0) {
      const err = new Error('الطلب غير موجود');
      err.status = 404;
      throw err;
    }
    const order = o.rows[0];
    if (order.status !== 'PENDING_ADMIN_APPROVAL') {
      const err = new Error('الطلب ليس بانتظار الموافقة');
      err.status = 400;
      throw err;
    }
    await client.query(
      `UPDATE orders SET status = 'CREDIT_REJECTED',
       credit_rejection_reason = $1, updated_at = NOW() WHERE id = $2`,
      [reason, orderId]
    );

    // أعد الكميات
    const its = await client.query(
      `SELECT product_id, quantity FROM order_items WHERE order_id = $1`,
      [orderId]
    );
    for (const it of its.rows) {
      await client.query(
        `UPDATE inventory SET reserved_qty = GREATEST(0, reserved_qty - $1),
         updated_at = NOW() WHERE product_id = $2`,
        [it.quantity, it.product_id]
      );
    }

    // اعكس الدين
    if (parseFloat(order.credit_amount || 0) > 0) {
      await ledgerService.addTransaction(client, {
        customerId: order.customer_id,
        orderId, transactionType: 'cancellation',
        credit: parseFloat(order.credit_amount),
        description: `رفض طلب آجل`,
        createdBy: adminId,
      });
    }

    await client.query(
      `INSERT INTO order_status_history (order_id, from_status, to_status, changed_by, reason)
       VALUES ($1, 'PENDING_ADMIN_APPROVAL', 'CREDIT_REJECTED', $2, $3)`,
      [orderId, adminId, `رفض: ${reason}`]
    );

    await client.query('COMMIT');
    return { id: orderId, status: 'CREDIT_REJECTED' };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

const listPendingCreditOrders = async () => {
  const r = await query(
    `SELECT o.id, o.order_number, o.status, o.total_amount, o.created_at,
            o.delivery_type, o.payment_terms,
            o.credit_amount, o.paid_amount_now,
            c.id AS customer_id, c.customer_type, c.current_balance, c.credit_limit,
            u.full_name AS customer_name, u.phone AS customer_phone
     FROM orders o
     JOIN customers c ON c.id = o.customer_id
     JOIN users u ON u.id = c.user_id
     WHERE o.status = 'PENDING_ADMIN_APPROVAL'
     ORDER BY o.created_at ASC`
  );
  return r.rows;
};

const getMyOrders = async (userId) => {
  const r = await query(
    `SELECT o.id, o.order_number, o.status, o.source,
            o.subtotal, o.shipping_amount, o.total_amount,
            o.paid_amount, o.remaining_amount,
            o.delivery_type, o.payment_terms, o.credit_rejection_reason,
            o.paid_amount_now, o.credit_amount, o.created_at,
            (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS items_count
     FROM orders o
     JOIN customers c ON c.id = o.customer_id
     WHERE c.user_id = $1
     ORDER BY o.created_at DESC`,
    [userId]
  );
  return r.rows;
};

const getOrderById = async (orderId, userId = null, isAdmin = false) => {
  let sql = `
    SELECT o.*, c.current_balance, c.credit_limit, c.customer_type,
           u.full_name AS customer_name, u.phone AS customer_phone,
           a.label AS address_label, a.governorate, a.area,
           a.address_text, a.alt_phone
    FROM orders o
    JOIN customers c ON c.id = o.customer_id
    JOIN users u ON u.id = c.user_id
    JOIN customer_addresses a ON a.id = o.address_id
    WHERE o.id = $1`;
  const params = [orderId];
  if (!isAdmin && userId) {
    sql += ` AND c.user_id = $2`;
    params.push(userId);
  }
  const r = await query(sql, params);
  if (r.rows.length === 0) return null;
  const order = r.rows[0];
  const its = await query(
    `SELECT oi.*, p.name_ar AS product_name, p.grade,
            s.name_ar AS source_name, s.code AS source_code,
            cat.name_ar AS category_name, cat.color_code, cat.color_name_ar
     FROM order_items oi
     JOIN products p ON p.id = oi.product_id
     JOIN product_sources s ON s.id = oi.source_id
     JOIN product_categories cat ON cat.id = p.category_id
     WHERE oi.order_id = $1`,
    [orderId]
  );
  order.items = its.rows;
  return order;
};

const cancelOrder = async (orderId, userId, reason) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const r = await client.query(
      `SELECT o.id, o.status, o.customer_id, o.credit_amount
       FROM orders o JOIN customers c ON c.id = o.customer_id
       WHERE o.id = $1 AND c.user_id = $2`,
      [orderId, userId]
    );
    if (r.rows.length === 0) {
      const err = new Error('الطلب غير موجود');
      err.status = 404;
      throw err;
    }
    const order = r.rows[0];
    if (!['PENDING_PRICING', 'PENDING_PAYMENT_METHOD', 'PENDING_PAYMENT', 'RECEIPT_UPLOADED', 'CREATED', 'PENDING_ADMIN_APPROVAL'].includes(order.status)) {
      const err = new Error('لا يمكن الإلغاء في هذه الحالة');
      err.status = 400;
      throw err;
    }
    const its = await client.query(
      `SELECT product_id, quantity FROM order_items WHERE order_id = $1`,
      [orderId]
    );
    for (const it of its.rows) {
      await client.query(
        `UPDATE inventory SET reserved_qty = GREATEST(0, reserved_qty - $1),
         updated_at = NOW() WHERE product_id = $2`,
        [it.quantity, it.product_id]
      );
    }
    await client.query(
      `UPDATE orders SET status = 'CANCELLED', updated_at = NOW() WHERE id = $1`,
      [orderId]
    );
    if (parseFloat(order.credit_amount || 0) > 0) {
      await ledgerService.addTransaction(client, {
        customerId: order.customer_id, orderId,
        transactionType: 'cancellation',
        credit: parseFloat(order.credit_amount),
        description: 'إلغاء طلب',
        createdBy: userId,
      });
    }
    await client.query(
      `INSERT INTO order_status_history (order_id, from_status, to_status, changed_by, reason)
       VALUES ($1, $2, 'CANCELLED', $3, $4)`,
      [orderId, order.status, userId, reason || 'إلغاء']
    );
    await client.query('COMMIT');
    return { id: orderId, status: 'CANCELLED' };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

module.exports = {
  createOrder, createGroupOrder, getGroupOrder,
  setOrderPricing, choosePaymentMethod, listPendingPricing,
  approveCreditOrder, rejectCreditOrder,
  listPendingCreditOrders, checkCreditAvailability,
  getMyOrders, getOrderById, cancelOrder,
};
